import { createFileRoute } from "@tanstack/react-router";
import { useState, type ComponentType, type ReactNode } from "react";
import {
  ChevronLeft,
  Banknote,
  Receipt,
  FileText,
  BarChart3,
  Users,
  FileSpreadsheet,
  Landmark,
  Download,
  Search,
  Plus,
  type LucideIcon,
} from "lucide-react";
import * as XLSX from "xlsx";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Card, Badge, BtnOutline, BtnPrimary, Input, Label } from "@/components/portal-shell";
import { DataTable, type Column } from "@/components/data-table";
import { FormDialog } from "@/components/form-dialog";
import { FileDropzone } from "@/components/file-dropzone";
import { useEffect } from "react";
import { isSupabaseConfigured, requireSupabase } from "@/lib/supabase";
import {
  listConciliacionesArchivos,
  createConciliacionArchivo,
} from "@/lib/api/conciliaciones";
import { parseBancoFile } from "@/lib/conciliacion/parse";
import { cruzarConciliacion, type AnalisisResumen } from "@/lib/conciliacion/engine";
import { listMovimientos } from "@/lib/api/movimientos";

export const Route = createFileRoute("/admin/administracion/reportes")({
  head: () => ({ meta: [{ title: "Reportes — Admin Panel" }] }),
  component: Page,
});

type ReportDef = {
  key: string;
  name: string;
  icon: LucideIcon;
  color: string;
  description: string;
};

const reports: ReportDef[] = [
  {
    key: "conciliaciones",
    name: "Conciliaciones Bancarias",
    icon: Banknote,
    color: "text-blue-500",
    description: "Transacciones diarias subidas por el banco.",
  },
  {
    key: "bcra",
    name: "Reportes BCRA",
    icon: Receipt,
    color: "text-emerald-500",
    description: "Reportes regulatorios para el Banco Central.",
  },
  {
    key: "afip",
    name: "Reportes AFIP",
    icon: FileText,
    color: "text-orange-500",
    description: "Regímenes informativos (ARCA / ex AFIP).",
  },
  {
    key: "comisiones",
    name: "Reportes de Comisiones",
    icon: BarChart3,
    color: "text-purple-500",
    description: "Comisiones por período y tipo de operación.",
  },
  {
    key: "movimientos",
    name: "Reportes de Movimientos",
    icon: FileText,
    color: "text-teal-500",
    description: "Movimientos de personas físicas y jurídicas fuera de la plataforma.",
  },
  {
    key: "actividad",
    name: "Actividad de Usuarios",
    icon: Users,
    color: "text-indigo-500",
    description: "Actividad registrada por legajo de backoffice.",
  },
  {
    key: "impuestos",
    name: "Reportes de Impuestos",
    icon: FileSpreadsheet,
    color: "text-red-500",
    description: "Retenciones presentadas y pagadas por período.",
  },
  {
    key: "conciliaciones-blp",
    name: "Conciliaciones BLP",
    icon: Landmark,
    color: "text-cyan-500",
    description: "Conciliación de archivos Payway (pagos y liquidaciones).",
  },
  {
    key: "unidad-negocio",
    name: "Reporte por Unidad de Negocio",
    icon: BarChart3,
    color: "text-amber-500",
    description: "Cuánto genera cada unidad: CBU, CBU chica U, QR, Link de Pago, E-commerce.",
  },
];

function downloadFile(filename: string, content: string) {
  const blob = new Blob([content], { type: "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function downloadExcel(filename: string, rows: Record<string, unknown>[]) {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Reporte");
  const wbout = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  const blob = new Blob([wbout], { type: "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function downloadCSV(filename: string, rows: Record<string, unknown>[]) {
  const cols = Object.keys(rows[0] ?? {});
  const escape = (v: unknown) => {
    const s = v == null ? "" : String(v);
    return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [
    cols.map(escape).join(","),
    ...rows.map((r) => cols.map((c) => escape(r[c])).join(",")),
  ];
  downloadFile(filename, lines.join("\n"));
}

type Archivo = {
  archivo: string;
  fecha: string;
  estado: "Analizado" | "Pendiente";
  downloadRows: Record<string, unknown>[];
  bankRows?: import("@/lib/conciliacion/parse").BankRow[];
  rawFile?: File | null;
  storagePath?: string | null;
};

const CONCILIACION_COLS = [
  "FECHA_NEGOCIO",
  "ID_DEBIN",
  "TIPO_MOV_COELSA",
  "CBU",
  "CTA_BT_DEL_CBU",
  "BT_SBO",
  "BT_TOP",
  "DENOMINACION",
  "CUIT",
  "IMPORTE_COELSA",
  "ESTADO_COELSA",
  "ASTO_ESTADO",
  "CVU",
  "CUIT_VIRTUAL",
  "CVU_2",
  "CUIT_VIRTUAL_2",
  "CBU_2",
  "CUIT_2",
  "CONCEPTO",
  "MISMO_TIT",
  "DETALLE",
  "CVU_CREDITO",
  "FECHA_HORA_COELSA",
];

const ARCHIVOS_INICIALES: Archivo[] = [];

function AnalisisConciliacionModal({
  archivo,
  allArchivos,
  onClose,
}: {
  archivo: Archivo;
  allArchivos: Archivo[];
  onClose: () => void;
}) {
  const [resumen, setResumen] = useState<AnalisisResumen | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [rangoLabel, setRangoLabel] = useState<string>("");
  const [movCount, setMovCount] = useState<number>(0);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      try {
        setLoading(true);
        setError(null);
        let bankRows = archivo.bankRows ?? null;
        // Si no hay bankRows en memoria, intentar obtener del storage o del downloadRows mock
        if (!bankRows || bankRows.length === 0) {
          if (archivo.rawFile) {
            bankRows = await parseBancoFile(archivo.rawFile);
          } else if (archivo.storagePath && isSupabaseConfigured) {
            const sb = requireSupabase();
            const { data, error: dlErr } = await sb.storage.from("conciliaciones").download(archivo.storagePath);
            if (dlErr) throw dlErr;
            const file = new File([data], archivo.archivo, { type: (data as Blob).type || "application/octet-stream" });
            bankRows = await parseBancoFile(file);
          } else if (archivo.downloadRows.length > 0) {
            // fallback mock -> convertir downloadRows a BankRow shape mínimo
            const mapped = archivo.downloadRows.map((r) => ({
              fechaNegocio: String((r as Record<string, unknown>)["FECHA_NEGOCIO"] ?? ""),
              idDebin: String((r as Record<string, unknown>)["ID_DEBIN"] ?? ""),
              tipoMovCoelsa: String((r as Record<string, unknown>)["TIPO_MOV_COELSA"] ?? ""),
              cbu: String((r as Record<string, unknown>)["CBU"] ?? ""),
              ctaBtDelCbu: "",
              btSbo: "",
              btTop: "",
              denominacion: "",
              cuit: "",
              importeRaw: String((r as Record<string, unknown>)["IMPORTE_COELSA"] ?? "0"),
              importeCoelsa: Number((r as Record<string, unknown>)["IMPORTE_COELSA"] ?? 0),
              estadoCoelsa: String((r as Record<string, unknown>)["ESTADO_COELSA"] ?? "COMPLETADA"),
              astoEstado: String((r as Record<string, unknown>)["ASTO_ESTADO"] ?? ""),
              cvu: String((r as Record<string, unknown>)["CVU"] ?? ""),
              cuitVirtual: "",
              cvu2: "",
              cuitVirtual2: "",
              cbu2: "",
              cuit2: "",
              concepto: "",
              mismoTit: "",
              detalle: "",
              cvuCredito: "",
              fechaHoraCoelsa: String((r as Record<string, unknown>)["FECHA_HORA_COELSA"] ?? ""),
              raw: r as Record<string, string>,
            })) as import("@/lib/conciliacion/parse").BankRow[];
            bankRows = mapped;
          } else {
            throw new Error("No hay datos del archivo para analizar. Volvé a cargar el archivo.");
          }
        }
        // Rango incremental: 1er reporte = todo hasta fecha carga, siguientes = (fecha último reporte, fecha actual]
        // (usuario confirmó: 20260903 full, siguiente delta desde último)
        let movimientos: import("@/lib/api/types").Movimiento[] = [];
        let movCountDebug = 0;
        let rangoLabel = "";
        if (isSupabaseConfigured) {
          const sorted = [...allArchivos].sort((a, b) => a.fecha.localeCompare(b.fecha));
          const idx = sorted.findIndex((a) => a.archivo === archivo.archivo);
          const prev = idx > 0 ? sorted[idx - 1] : null;
          let desde: string | undefined;
          let hasta: string | undefined;
          if (prev) {
            const dPrev = new Date(prev.fecha + "T00:00:00");
            dPrev.setDate(dPrev.getDate() + 1);
            desde = dPrev.toISOString();
            hasta = new Date(archivo.fecha + "T00:00:00").toISOString();
            // incluir todo el día hasta 23:59
            const h = new Date(hasta);
            h.setHours(23, 59, 59, 999);
            hasta = h.toISOString();
            rangoLabel = `${prev.fecha} → ${archivo.fecha} (delta)`;
          } else {
            // primer reporte: histórico hasta fecha carga
            hasta = new Date(archivo.fecha + "T00:00:00").toISOString();
            const h = new Date(hasta);
            h.setHours(23, 59, 59, 999);
            hasta = h.toISOString();
            desde = undefined;
            rangoLabel = `histórico hasta ${archivo.fecha}`;
          }
          try {
            // Paginado para histórico grande (>5000)
            const all: import("@/lib/api/types").Movimiento[] = [];
            let page = 0;
            const pageSize = 5000;
            while (true) {
              const resPage = await listMovimientos({ page, pageSize, fechaDesde: desde, fechaHasta: hasta });
              all.push(...resPage.rows);
              movCountDebug = resPage.total ?? all.length;
              if (resPage.rows.length < pageSize) break;
              page++;
              if (page > 20) break; // safety cap 100k
            }
            movimientos = all;
          } catch {
            movimientos = [];
          }
          if (!cancelled) {
            setRangoLabel(rangoLabel);
            setMovCount(movCountDebug);
          }
        }
        const res = cruzarConciliacion(bankRows!, movimientos);
        if (!cancelled) setResumen(res);
      } catch (e: unknown) {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [archivo, allArchivos]);

  const porcentaje = resumen ? (resumen.total > 0 ? Math.round((resumen.encontrados / resumen.total) * 10000) / 100 : 0) : 0;
  const fechaAnalisis = resumen?.fechaAnalisis ?? "";

  const Kpi = ({
    label,
    value,
    accent,
  }: {
    label: string;
    value: string | number;
    accent?: boolean;
  }) => (
    <div
      className={`rounded-lg border px-2.5 py-2.5 text-center ${
        accent ? "bg-primary/[0.06] border-primary/20" : "bg-muted/30 border-border/50"
      }`}
    >
      <div className="font-display text-[18px] font-semibold leading-none tracking-tight tabular-nums text-foreground">
        {value}
      </div>
      <div className="text-[10.5px] font-medium uppercase tracking-widest text-muted-foreground mt-1.5 leading-none">
        {label}
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-card rounded-xl w-full max-w-3xl max-h-[88vh] overflow-y-auto shadow-xl">
        <div className="sticky top-0 bg-card border-b border-border px-5 py-3.5 flex justify-between items-start z-10">
          <div>
            <h3 className="font-display text-[15px] font-semibold leading-none">Análisis de conciliación</h3>
            <p className="text-xs text-muted-foreground mt-1 font-mono">
              {archivo.archivo} · {archivo.fecha} {rangoLabel ? `· ${rangoLabel}` : ""}
            </p>
            {rangoLabel && <p className="text-[11px] text-muted-foreground mt-0.5">Rango plataforma: {rangoLabel} — 1er reporte histórico, siguientes delta desde último.</p>}
          </div>
          <button type="button" onClick={onClose} className="p-1.5 hover:bg-muted rounded-md leading-none">
            ×
          </button>
        </div>

        <div className="p-5 space-y-4">
          {loading && <p className="text-sm text-muted-foreground">Analizando… cruzando ID_DEBIN ↔ id_txn y montos…</p>}
          {error && <p className="text-sm text-red-600">Error: {error}</p>}
          {resumen && !loading && !error && (
            <>
              {/* Resumen + éxito */}
              <Card className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-display text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                    Resumen general
                  </h4>
                  <span className="inline-flex items-center rounded-full bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                    {porcentaje}% éxito · {resumen.encontrados}/{resumen.total}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-2">
                  <Kpi label="Total" value={resumen.total} />
                  <Kpi label="Encontrados" value={resumen.encontrados} accent />
                  <Kpi label="No encontrados" value={resumen.noEncontrados} />
                  <Kpi label="No completados" value={resumen.noCompletados} />
                  <Kpi label="Dif. monto" value={resumen.diferenciasMonto} />
                  <Kpi label="Éxito" value={`${porcentaje}%`} accent />
                </div>
                {resumen.soloPlataforma > 0 && (
                  <p className="text-[11px] text-amber-600 mt-2">+ {resumen.soloPlataforma} movimientos solo en plataforma (no están en banco)</p>
                )}
              </Card>

              <Card className="p-4">
                <h4 className="font-display text-[11px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                  Distribución por tipo (TIPO_MOV_COELSA: CREDITO=Depósito / DEBITO=Retiro)
                </h4>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                  <Kpi label="Depósitos · total" value={resumen.depositos.total} />
                  <Kpi label="Depósitos · encontrados" value={resumen.depositos.encontrados} />
                  <Kpi label="Retiros · total" value={resumen.retiros.total} />
                  <Kpi label="Retiros · encontrados" value={resumen.retiros.encontrados} />
                </div>
              </Card>

              <Card className="p-4">
                <h4 className="font-display text-[11px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                  No encontrados — detalle paginado (10 por página) · cruce ID_DEBIN → id_txn (+ fallback monto+fecha)
                </h4>
                {(() => {
                  const noEncontrados = resumen.items.filter((it) => it.estado === "no_encontrado");
                  if (noEncontrados.length === 0) return <span className="inline-flex rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">Sin IDs — todo conciliado</span>;
                  type RowNE = { id: string; tipo: string; importe: number; fecha: string; cvu: string };
                  const rows: RowNE[] = noEncontrados.map((it) => ({ id: it.bankRow.idDebin, tipo: it.bankRow.tipoMovCoelsa, importe: it.bankRow.importeCoelsa, fecha: it.bankRow.fechaHoraCoelsa || it.bankRow.fechaNegocio, cvu: it.bankRow.cvu }));
                  const cols: import("@/components/data-table").Column<RowNE>[] = [
                    { key: "id", label: "ID_DEBIN", filterable: true, render: (r) => <span className="font-mono text-[11px]">{r.id}</span> },
                    { key: "tipo", label: "Tipo", filterable: "enum", filterOptions: ["CREDITO", "DEBITO"], render: (r) => r.tipo },
                    { key: "importe", label: "Importe", sortable: true, render: (r) => <span className="font-mono tabular-nums">{r.importe.toLocaleString("es-AR", { minimumFractionDigits: 2 })}</span> },
                    { key: "fecha", label: "Fecha", sortable: true, render: (r) => <span className="font-mono text-xs">{r.fecha}</span> },
                    { key: "cvu", label: "CVU", filterable: true, render: (r) => <span className="font-mono text-[11px]">{r.cvu || "—"}</span> },
                  ];
                  return <DataTable columns={cols} data={rows} keyExtractor={(r) => r.id} pageSize={10} />;
                })()}
                {resumen.idsDiferenciaMonto.length > 0 && (
                  <div className="mt-3">
                    <div className="text-[11px] font-semibold text-muted-foreground mb-1.5">Diferencias de monto ({resumen.idsDiferenciaMonto.length})</div>
                    <div className="flex flex-wrap gap-1">
                      {resumen.idsDiferenciaMonto.map((id) => (
                        <span key={id} className="inline-flex rounded-md border border-red-200 bg-red-50 px-1.5 py-0.5 font-mono text-[11px] text-red-700">
                          {id}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                <p className="text-[11px] text-muted-foreground mt-3">
                  Movimientos consultados en plataforma: {movCount} · Rango {rangoLabel || archivo.fecha} · Si ves 0, la tabla <code>movimientos</code> no tiene filas para ese rango o RLS lo bloquea; entonces 0 conciliados es esperado.
                </p>
              </Card>
              <div className="grid lg:grid-cols-[1.35fr_0.65fr] gap-4">
                <Card className="p-4">
                  <h4 className="font-display text-[11px] font-semibold uppercase tracking-widest text-muted-foreground mb-3">IDs resumidos</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <div className="text-[11px] font-semibold text-muted-foreground mb-1.5">Depósitos (CREDITO)</div>
                      {resumen.idsDepositosNoEncontrados.length === 0 ? (
                        <span className="inline-flex rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">Sin IDs</span>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {resumen.idsDepositosNoEncontrados.slice(0, 20).map((id) => (
                            <span key={id} className="inline-flex rounded-md border border-border bg-muted/40 px-1.5 py-0.5 font-mono text-[11px]">{id}</span>
                          ))}
                          {resumen.idsDepositosNoEncontrados.length > 20 && <span className="text-xs text-muted-foreground">+{resumen.idsDepositosNoEncontrados.length - 20} más (ver tabla)</span>}
                        </div>
                      )}
                    </div>
                    <div>
                      <div className="text-[11px] font-semibold text-muted-foreground mb-1.5">Retiros (DEBITO)</div>
                      {resumen.idsRetirosNoEncontrados.length === 0 ? (
                        <span className="inline-flex rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">Sin IDs</span>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {resumen.idsRetirosNoEncontrados.slice(0, 20).map((id) => (
                            <span key={id} className="inline-flex rounded-md border border-amber-200 bg-amber-50 px-1.5 py-0.5 font-mono text-[11px] text-amber-800 dark:border-amber-900/40 dark:bg-amber-950/30 dark:text-amber-300">{id}</span>
                          ))}
                          {resumen.idsRetirosNoEncontrados.length > 20 && <span className="text-xs text-muted-foreground">+{resumen.idsRetirosNoEncontrados.length - 20} más</span>}
                        </div>
                      )}
                    </div>
                  </div>
                </Card>

                <Card className="p-4 flex flex-col justify-between">
                  <div>
                    <h4 className="font-display text-[11px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">Análisis</h4>
                    <p className="font-mono text-xs font-medium tabular-nums">{fechaAnalisis}</p>
                    <p className="text-[11px] text-muted-foreground mt-1 leading-snug">{resumen.encontrados} de {resumen.total} conciliados — mapeo ID_DEBIN= id_txn, |IMPORTE_COELSA|= monto_operacion</p>
                  </div>
                  <BtnOutline
                    className="mt-3 h-7 text-xs px-2.5 w-full justify-center"
                    onClick={() => {
                      const rows = resumen.items.map((it) => ({
                        ID_DEBIN: it.bankRow.idDebin,
                        TIPO: it.bankRow.tipoMovCoelsa,
                        IMPORTE_BANCO: it.bankRow.importeCoelsa,
                        ESTADO_BANCO: it.bankRow.estadoCoelsa,
                        id_txn_plataforma: it.movimiento?.idTxn ?? "",
                        monto_plataforma: it.movimiento?.montoOperacion ?? "",
                        estado_cruce: it.estado,
                        detalle: it.detalle,
                      }));
                      const cols = Object.keys(rows[0] ?? {});
                      const esc = (v: unknown) => {
                        const s = v == null ? "" : String(v);
                        return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
                      };
                      const csv = [cols.join(","), ...rows.map((r) => cols.map((c) => esc((r as Record<string, unknown>)[c])).join(","))].join("\n");
                      downloadFile(`cruce_${archivo.archivo.replace(/\.[^.]+$/, "")}.csv`, csv);
                    }}
                  >
                    <Download size={14} /> Descargar cruce CSV
                  </BtnOutline>
                </Card>
              </div>
            </>
          )}
        </div>

        <div className="sticky bottom-0 bg-card border-t border-border px-5 py-3 flex justify-end">
          <BtnOutline onClick={onClose} className="h-8 text-xs px-4">
            Cerrar
          </BtnOutline>
        </div>
      </div>
    </div>
  );
}

function Conciliaciones() {
  const [archivos, setArchivos] = useState<Archivo[]>(ARCHIVOS_INICIALES);
  const [analisisTarget, setAnalisisTarget] = useState<Archivo | null>(null);
  const [cargando, setCargando] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploadForm, setUploadForm] = useState({
    nombre: "",
    fecha: "",
    file: null as File | null,
  });

  // Carga inicial desde Supabase si está configurado - cada fila refleja DB
  useEffect(() => {
    if (!isSupabaseConfigured) return;
    listConciliacionesArchivos({ page: 0, pageSize: 50, tipo: "bancaria" })
      .then((res) => {
        if (res.rows.length > 0) {
          setArchivos(
            res.rows.map((r) => ({
              archivo: r.nombreArchivo,
              fecha: r.fechaCarga,
              estado: (r.estado === "Analizado" ? "Analizado" : "Pendiente") as Archivo["estado"],
              downloadRows: [],
              storagePath: r.storagePath,
              bankRows: undefined,
              rawFile: null,
            })),
          );
        }
      })
      .catch(() => {
        // fallback a mocks si RLS/migración aún no aplicada
      });
  }, []);

  const guardarArchivo = async () => {
    if (!uploadForm.nombre.trim() || !uploadForm.fecha || !uploadForm.file) {
      toast.error("Completá nombre, fecha y archivo");
      return;
    }
    const nombreArchivo = uploadForm.file.name || uploadForm.nombre.trim();
    // Parsear localmente para tener bankRows listos para Analizar (mapeo real aunque falle Supabase)
    let parsed: import("@/lib/conciliacion/parse").BankRow[] = [];
    let downloadRows: Record<string, unknown>[] = [];
    try {
      parsed = await parseBancoFile(uploadForm.file);
      downloadRows = parsed.map((b) => ({ ...b.raw, IMPORTE_COELSA: b.importeCoelsa })) as Record<string, unknown>[];
      toast.success(`Parseado: ${parsed.length} filas (mapeo ID_DEBIN→id_txn)`);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      toast.error(`Error parseando archivo: ${msg}`);
      return;
    }
    // Persistencia real si hay Supabase
    if (isSupabaseConfigured) {
      setSaving(true);
      try {
        const created = await createConciliacionArchivo({
          nombreArchivo,
          fechaCarga: uploadForm.fecha,
          tipo: "bancaria",
          estado: "Pendiente",
          file: uploadForm.file,
        });
        setArchivos((prev) => [
          {
            archivo: created.nombreArchivo,
            fecha: created.fechaCarga,
            estado: "Pendiente",
            downloadRows,
            bankRows: parsed,
            rawFile: uploadForm.file,
            storagePath: created.storagePath,
          },
          ...prev,
        ]);
        toast.success("Archivo guardado en base de datos");
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : String(e);
        if (/Could not find the table|PGRST205|does not exist/i.test(msg)) {
          setArchivos((prev) => [
            { archivo: nombreArchivo, fecha: uploadForm.fecha, estado: "Pendiente", downloadRows, bankRows: parsed, rawFile: uploadForm.file },
            ...prev,
          ]);
          toast.success("Archivo cargado (modo local: aplicá migración 0016)");
        } else {
          toast.error(`Error al guardar: ${msg}`);
          setSaving(false);
          return;
        }
      } finally {
        setSaving(false);
      }
    } else {
      setArchivos((prev) => [
        { archivo: nombreArchivo, fecha: uploadForm.fecha, estado: "Pendiente", downloadRows, bankRows: parsed, rawFile: uploadForm.file },
        ...prev,
      ]);
      toast.success("Archivo cargado correctamente");
    }
    setUploadForm({ nombre: "", fecha: "", file: null });
    setCargando(false);
  };

  const columns: Column<Archivo>[] = [
    {
      key: "archivo",
      label: "Archivo",
      filterable: true,
      render: (r) => <span className="font-mono text-xs">{r.archivo}</span>,
    },
    {
      key: "fecha",
      label: "Fecha",
      filterable: "date",
      render: (r) => <span className="font-mono tabular-nums">{r.fecha}</span>,
    },
    {
      key: "analizar",
      label: "Acción",
      render: (r) => (
        <div className="flex items-center gap-1">
          <BtnOutline
            className="h-7 text-xs px-3"
            onClick={() => {
              downloadExcel(r.archivo.replace(".csv", ".xlsx"), r.downloadRows);
              toast.success("Archivo descargado correctamente");
            }}
          >
            <Download size={14} /> Descargar
          </BtnOutline>
          <BtnOutline className="h-7 text-xs px-3" onClick={() => setAnalisisTarget(r)}>
            Analizar
          </BtnOutline>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
        <p className="text-sm text-muted-foreground">
          El banco sube diariamente (día anterior) todas las transacciones.
        </p>
        <BtnPrimary type="button" className="h-9 text-sm" onClick={() => setCargando(true)}>
          <Plus size={14} /> Cargar CSV
        </BtnPrimary>
      </div>
      <DataTable columns={columns} data={archivos} keyExtractor={(r) => r.archivo} />

      {analisisTarget && (
        <AnalisisConciliacionModal
          archivo={analisisTarget}
          allArchivos={archivos}
          onClose={() => setAnalisisTarget(null)}
        />
      )}

      {cargando && (
        <FormDialog
          open
          onClose={() => (saving ? null : setCargando(false))}
          title="Cargar archivo de conciliación"
          description="Ingresá el nombre, la fecha de carga y el archivo CSV. Se guarda en la base de datos."
          onSubmit={guardarArchivo}
          submitLabel={saving ? "Guardando..." : "Guardar"}
          cancelLabel="Cancelar"
          size="md"
        >
          <div>
            <Label htmlFor="conc-nombre">Nombre del archivo</Label>
            <Input
              id="conc-nombre"
              value={uploadForm.nombre}
              onChange={(e) => setUploadForm((f) => ({ ...f, nombre: e.target.value }))}
              placeholder="conciliacion_20260801.csv"
            />
          </div>
          <div>
            <Label htmlFor="conc-fecha">Fecha de carga</Label>
            <input
              id="conc-fecha"
              type="date"
              value={uploadForm.fecha}
              onChange={(e) => setUploadForm((f) => ({ ...f, fecha: e.target.value }))}
              className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40 [color-scheme:light] dark:[color-scheme:dark]"
            />
          </div>
          <div>
            <Label>Archivo CSV</Label>
            <FileDropzone
              accept=".csv,.xlsx,.xls"
              onFile={(f) =>
                setUploadForm((fr) => ({ ...fr, file: f, nombre: f?.name ?? fr.nombre }))
              }
            />
          </div>
        </FormDialog>
      )}
    </div>
  );
}

/* ---------- Reportes BCRA (BSRA) ---------- */

function ReportesBCRA() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <Label htmlFor="bsra-fecha">Fecha</Label>
          <input
            id="bsra-fecha"
            type="month"
            defaultValue="2026-07"
            className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40 [color-scheme:light] dark:[color-scheme:dark]"
          />
        </div>
        <BtnOutline className="h-9 text-xs px-3">
          <Search size={14} /> Buscar
        </BtnOutline>
      </div>

      <BsraTabla />
    </div>
  );
}

type BsraRow = {
  fecha: string;
  apartadoA: string;
  apartadoB: string;
  padron: string;
};

const bsraData: BsraRow[] = [
  {
    fecha: "01/08/2026",
    apartadoA: "202608A.csv",
    apartadoB: "202608B.xls",
    padron: "202608P.xls",
  },
  {
    fecha: "01/07/2026",
    apartadoA: "202607A.csv",
    apartadoB: "202607B.xls",
    padron: "202607P.xls",
  },
  {
    fecha: "01/06/2026",
    apartadoA: "202606A.csv",
    apartadoB: "202606B.xls",
    padron: "202606P.xls",
  },
  {
    fecha: "01/05/2026",
    apartadoA: "202605A.csv",
    apartadoB: "202605B.xls",
    padron: "202605P.xls",
  },
];

function BsraTabla() {
  const columns: Column<BsraRow>[] = [
    {
      key: "aperturaA",
      label: "Apartado A",
      sortable: true,
      filterable: true,
      render: (r) => (
        <button
          type="button"
          onClick={() =>
            downloadExcel(r.apartadoA.replace(".csv", ".xls"), [
              { concepto: "Apertura A", valor: 0 },
            ])
          }
          className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
        >
          <Download size={14} /> XLS
        </button>
      ),
    },
    {
      key: "aperturaB",
      label: "Apartado B",
      sortable: true,
      filterable: true,
      render: (r) => (
        <button
          type="button"
          onClick={() => downloadExcel(r.apartadoB, [{ concepto: "Apertura B", saldo: 0 }])}
          className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
        >
          <Download size={14} /> XLS
        </button>
      ),
    },
    {
      key: "padron",
      label: "Padrón",
      sortable: true,
      filterable: true,
      render: (r) => (
        <button
          type="button"
          onClick={() => downloadExcel(r.padron, [{ concepto: "Padrón", total: 0 }])}
          className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
        >
          <Download size={14} /> XLS
        </button>
      ),
    },
    {
      key: "fecha",
      label: "Fecha",
      sortable: true,
      filterable: "date",
      render: (r) => <span className="font-mono text-xs tabular-nums">{r.fecha}</span>,
    },
  ];
  return (
    <DataTable columns={columns} data={bsraData} keyExtractor={(r) => r.fecha} pageSize={10} />
  );
}

type AfipParams = {
  montoTransaccion: string;
  montoSaldo: string;
};

const afipParamsIniciales: AfipParams = {
  montoTransaccion: "500000",
  montoSaldo: "100000",
};

/* ---------- Reportes AFIP (B-8-1-25 / B-8-1-26) ---------- */

function ReportesAFIP() {
  const [params, setParams] = useState<AfipParams>(afipParamsIniciales);

  const guardarParams = () => {
    toast.success("Parámetros para reportes actualizados");
  };

  return (
    <div className="space-y-6">
      <Card className="p-5">
        <h4 className="font-display text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-4">
          Parámetros para reportes
        </h4>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="afip-monto-txn">Monto de transacción por mes</Label>
            <Input
              id="afip-monto-txn"
              value={params.montoTransaccion}
              onChange={(e) => setParams({ ...params, montoTransaccion: e.target.value })}
              placeholder="Ej: 500000"
            />
          </div>
          <div>
            <Label htmlFor="afip-monto-saldo">Monto de saldo a fin de mes</Label>
            <Input
              id="afip-monto-saldo"
              value={params.montoSaldo}
              onChange={(e) => setParams({ ...params, montoSaldo: e.target.value })}
              placeholder="Ej: 100000"
            />
          </div>
        </div>
        <div className="mt-4">
          <BtnPrimary className="h-8 text-xs px-3" onClick={guardarParams}>
            Guardar
          </BtnPrimary>
        </div>
      </Card>

      <AfipTabla params={params} />
    </div>
  );
}

type AfipRow = { fecha: string; b8125: string; b8126: string };

const afipData: AfipRow[] = [
  { fecha: "01/08/2026", b8125: "B-8-1-25_202608.xlsx", b8126: "B-8-1-26_202608.xlsx" },
  { fecha: "01/07/2026", b8125: "B-8-1-25_202607.xlsx", b8126: "B-8-1-26_202607.xlsx" },
  { fecha: "01/06/2026", b8125: "B-8-1-25_202606.xlsx", b8126: "B-8-1-26_202606.xlsx" },
  { fecha: "01/05/2026", b8125: "B-8-1-25_202605.xlsx", b8126: "B-8-1-26_202605.xlsx" },
];

function AfipTabla({ params }: { params: AfipParams }) {
  const filaReporte = (r: AfipRow) => ({
    concepto: "Reporte AFIP",
    periodo: r.fecha,
    monto_transaccion_mes: params.montoTransaccion,
    monto_saldo_fin_mes: params.montoSaldo,
  });

  const columns: Column<AfipRow>[] = [
    {
      key: "b8125",
      label: "B8125",
      sortable: true,
      filterable: true,
      render: (r) => (
        <button
          type="button"
          onClick={() => downloadExcel(r.b8125, [filaReporte(r)])}
          className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
        >
          <Download size={14} /> XLS
        </button>
      ),
    },
    {
      key: "b8126",
      label: "B8126",
      sortable: true,
      filterable: true,
      render: (r) => (
        <button
          type="button"
          onClick={() => downloadExcel(r.b8126, [filaReporte(r)])}
          className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
        >
          <Download size={14} /> XLS
        </button>
      ),
    },
    {
      key: "fecha",
      label: "Fecha",
      sortable: true,
      filterable: "date",
      render: (r) => <span className="font-mono text-xs tabular-nums">{r.fecha}</span>,
    },
  ];

  return (
    <DataTable
      columns={columns}
      data={afipData}
      keyExtractor={(r) => r.fecha}
      pageSize={10}
      showDownloadButton={false}
    />
  );
}

/* ---------- Reportes de Comisiones ---------- */

type Comision = {
  periodo: string;
  tipo: string;
  cantidad: number;
  monto: string;
  comision: string;
  enCurso: boolean;
};

function ReportesComisiones() {
  const hoy = new Date();
  const pm = String(hoy.getMonth() + 1).padStart(2, "0");
  const py = hoy.getFullYear();
  const cursoMes = `01/${pm}/${py}`;

  const data: Comision[] = [
    {
      periodo: cursoMes,
      tipo: "Depósitos",
      cantidad: 820,
      monto: "$ 8.200.000",
      comision: "$ 123.000",
      enCurso: true,
    },
    {
      periodo: cursoMes,
      tipo: "Retiros",
      cantidad: 540,
      monto: "$ 5.400.000",
      comision: "$ 81.000",
      enCurso: true,
    },
    {
      periodo: "01/07/2026",
      tipo: "Depósitos",
      cantidad: 1245,
      monto: "$ 12.450.000",
      comision: "$ 186.750",
      enCurso: false,
    },
    {
      periodo: "01/07/2026",
      tipo: "Retiros",
      cantidad: 892,
      monto: "$ 8.920.000",
      comision: "$ 133.800",
      enCurso: false,
    },
    {
      periodo: "01/07/2026",
      tipo: "Transferencias",
      cantidad: 3456,
      monto: "$ 34.560.000",
      comision: "$ 518.400",
      enCurso: false,
    },
    {
      periodo: "01/06/2026",
      tipo: "Depósitos",
      cantidad: 1187,
      monto: "$ 11.870.000",
      comision: "$ 178.050",
      enCurso: false,
    },
    {
      periodo: "01/05/2026",
      tipo: "Depósitos",
      cantidad: 1050,
      monto: "$ 10.500.000",
      comision: "$ 157.500",
      enCurso: false,
    },
  ];
  const columns: Column<Comision>[] = [
    {
      key: "periodo",
      label: "Período",
      filterable: "date",
      sortable: true,
      render: (r) => (
        <span className="font-mono tabular-nums">
          {r.periodo}
          {r.enCurso ? (
            <Badge tone="warn" className="ml-1.5">
              En curso
            </Badge>
          ) : null}
        </span>
      ),
    },
    { key: "tipo", label: "Tipo", filterable: true, render: (r) => r.tipo },
    {
      key: "cantidad",
      label: "Cantidad",
      filterable: true,
      sortable: true,
      render: (r) => r.cantidad.toLocaleString(),
    },
    {
      key: "monto",
      label: "Monto cobrado",
      sortable: true,
      render: (r) => <span className="font-mono tabular-nums">{r.monto}</span>,
    },
    {
      key: "comision",
      label: "Comisión",
      sortable: true,
      render: (r) => <span className="font-mono tabular-nums">{r.comision}</span>,
    },
    {
      key: "xls",
      label: "XLS",
      render: (r) => (
        <button
          type="button"
          onClick={() =>
            downloadExcel(`comisiones_${r.periodo}_${r.tipo}.xlsx`, [
              {
                periodo: r.periodo,
                tipo: r.tipo,
                cantidad: r.cantidad,
                monto: r.monto,
                comision: r.comision,
              },
            ])
          }
          className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
        >
          <Download size={14} /> XLS
        </button>
      ),
    },
  ];
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Badge tone="warn">Reporte en curso</Badge>
        <span>
          Los períodos marcados como "En curso" corresponden al mes actual y reflejan las comisiones
          acumuladas hasta ahora. Al finalizar el mes se genera el reporte definitivo.
        </span>
      </div>
      <DataTable
        columns={columns}
        data={data}
        keyExtractor={(r) => r.periodo + r.tipo}
        pageSize={10}
        showDownloadButton={false}
      />
    </div>
  );
}

/* ---------- Reportes de Movimientos (CUIT) ---------- */

type Movimiento = {
  coelsaId: string;
  legajo: string;
  email: string;
  cvu: string;
  dia: string;
  hora: string;
  tipo: "Depósito" | "Retiro";
  monto: string;
  cvuRemitente: string;
  cuitRemitente: string;
  nombreRemitente: string;
};

const MOVIMIENTOS: Record<string, Movimiento[]> = {
  "30123456789": [
    {
      coelsaId: "COELSA-0001",
      legajo: "LPF-20123456789",
      email: "jperez@email.com",
      cvu: "1234567890123456789012",
      dia: "2026-07-28",
      hora: "14:32",
      tipo: "Depósito",
      monto: "$ 50.000",
      cvuRemitente: "1234567890123456789012",
      cuitRemitente: "30123456789",
      nombreRemitente: "Juan Pérez",
    },
    {
      coelsaId: "COELSA-0002",
      legajo: "LPF-20123456789",
      email: "jperez@email.com",
      cvu: "1234567890123456789012",
      dia: "2026-07-26",
      hora: "09:15",
      tipo: "Retiro",
      monto: "$ 5.000",
      cvuRemitente: "1234567890123456789023",
      cuitRemitente: "20123456789",
      nombreRemitente: "María García",
    },
    {
      coelsaId: "COELSA-0003",
      legajo: "LPF-20123456789",
      email: "jperez@email.com",
      cvu: "1234567890123456789012",
      dia: "2026-07-20",
      hora: "10:45",
      tipo: "Depósito",
      monto: "$ 120.000",
      cvuRemitente: "1234567890123456789934",
      cuitRemitente: "30555666777",
      nombreRemitente: "María García",
    },
  ],
  "20123456789": [
    {
      coelsaId: "COELSA-0004",
      legajo: "LPF-27234567890",
      email: "mgarcia@email.com",
      cvu: "1234567890123456789023",
      dia: "2026-07-28",
      hora: "11:00",
      tipo: "Depósito",
      monto: "$ 200.000",
      cvuRemitente: "1234567890123456789012",
      cuitRemitente: "30123456789",
      nombreRemitente: "Juan Pérez",
    },
    {
      coelsaId: "COELSA-0005",
      legajo: "LPF-27234567890",
      email: "mgarcia@email.com",
      cvu: "1234567890123456789023",
      dia: "2026-07-22",
      hora: "08:30",
      tipo: "Retiro",
      monto: "$ 25.000",
      cvuRemitente: "1234567890123456789023",
      cuitRemitente: "30555666777",
      nombreRemitente: "Carlos López",
    },
  ],
  "30987654321": [
    {
      coelsaId: "COELSA-0006",
      legajo: "LPF-20345678901",
      email: "clopez@email.com",
      cvu: "1234567890123456789034",
      dia: "2026-07-25",
      hora: "16:00",
      tipo: "Depósito",
      monto: "$ 75.000",
      cvuRemitente: "1234567890123456789012",
      cuitRemitente: "30123456789",
      nombreRemitente: "Ana Martínez",
    },
  ],
};

function ReportesMovimientos() {
  const [cuit, setCuit] = useState("");
  const [consulta, setConsulta] = useState("");
  const valido = /^\d{11}$/.test(cuit);
  const rows = consulta ? (MOVIMIENTOS[consulta] ?? []) : [];

  const columns: Column<Movimiento>[] = [
    {
      key: "coelsaId",
      label: "ID COELSA",
      sortable: true,
      filterable: true,
      render: (r) => <span className="font-mono text-xs">{r.coelsaId}</span>,
    },
    {
      key: "legajo",
      label: "Legajo",
      sortable: true,
      filterable: true,
      render: (r) => <span className="font-mono tabular-nums">{r.legajo}</span>,
    },
    { key: "email", label: "Email", filterable: true, render: (r) => r.email },
    {
      key: "cvu",
      label: "CVU",
      filterable: true,
      render: (r) => <span className="font-mono text-xs tabular-nums">{r.cvu}</span>,
    },
    {
      key: "dia",
      label: "Día",
      sortable: true,
      filterable: "date",
      render: (r) => <span className="font-mono tabular-nums">{r.dia}</span>,
    },
    {
      key: "hora",
      label: "Hora",
      sortable: true,
      render: (r) => <span className="font-mono tabular-nums">{r.hora}</span>,
    },
    {
      key: "tipo",
      label: "Tipo",
      sortable: true,
      filterable: "enum",
      filterOptions: ["Depósito", "Retiro"],
      render: (r) => r.tipo,
    },
    {
      key: "monto",
      label: "Monto",
      sortable: true,
      render: (r) => <span className="font-mono tabular-nums">{r.monto}</span>,
    },
    {
      key: "cvuRemitente",
      label: "CVU remitente",
      filterable: true,
      render: (r) => (
        <span className="font-mono text-xs tabular-nums">{r.cvuRemitente || "—"}</span>
      ),
    },
    {
      key: "cuitRemitente",
      label: "CUIT remitente",
      filterable: true,
      render: (r) => (
        <span className="font-mono tabular-nums text-xs">{r.cuitRemitente || "—"}</span>
      ),
    },
    {
      key: "nombreRemitente",
      label: "Nombre remitente",
      filterable: true,
      render: (r) => r.nombreRemitente || "—",
    },
  ];

  const excelRows = rows.map((r) => ({
    "ID COELSA": r.coelsaId,
    Legajo: r.legajo,
    Email: r.email,
    CVU: r.cvu,
    Día: r.dia,
    Hora: r.hora,
    Tipo: r.tipo,
    Monto: r.monto,
    "CVU remitente": r.cvuRemitente,
    "CUIT remitente": r.cuitRemitente,
    "Nombre remitente": r.nombreRemitente,
  }));

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Ingresá un CUIT (11 dígitos) para consultar y descargar en Excel los movimientos de personas
        físicas y jurídicas fuera de la plataforma.
      </p>
      <div className="flex items-end gap-3 flex-wrap">
        <div className="flex-1 min-w-[220px]">
          <Label htmlFor="cuit-mov">CUIT</Label>
          <Input
            id="cuit-mov"
            value={cuit}
            onChange={(e) => {
              const v = e.target.value.replace(/\D/g, "").slice(0, 11);
              setCuit(v);
              if (v.length !== 11) setConsulta("");
            }}
            placeholder="Ej: 20123456789"
          />
        </div>
        <button
          disabled={!valido}
          onClick={() => setConsulta(cuit)}
          className="inline-flex items-center gap-2 h-10 px-4 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Search size={14} /> Buscar
        </button>
      </div>
      {cuit.length > 0 && !valido && (
        <p className="text-xs text-amber-600">El CUIT debe tener 11 dígitos numéricos.</p>
      )}
      {valido && consulta && (
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <BtnOutline onClick={() => downloadExcel(`movimientos_${consulta}.xlsx`, excelRows)}>
              <Download size={14} /> Descargar Excel
            </BtnOutline>
            <span className="text-sm text-muted-foreground">
              {rows.length} movimientos encontrados
            </span>
          </div>
        </div>
      )}
      {consulta &&
        valido &&
        (rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No se encontraron movimientos para el CUIT consultado.
          </p>
        ) : (
          <DataTable
            columns={columns}
            data={rows}
            keyExtractor={(r) => r.coelsaId}
            pageSize={10}
            showDownloadButton={false}
          />
        ))}
    </div>
  );
}

/* ---------- Actividad de Usuarios ---------- */

type Actividad = {
  campo: string;
  valorAnterior: string;
  valorNuevo: string;
  fecha: string;
  hora: string;
  usuario: string;
};

const ACTIVIDAD_BASE: Record<string, Actividad[]> = {
  "ADM-001": [
    {
      campo: "Estado",
      valorAnterior: "Pendiente",
      valorNuevo: "Activo",
      fecha: "15/07/2026",
      hora: "14:32",
      usuario: "admin.operaciones",
    },
    {
      campo: "Email",
      valorAnterior: "mrodriguez@oldmail.com",
      valorNuevo: "mrodriguez@molipay.com",
      fecha: "15/07/2026",
      hora: "11:15",
      usuario: "admin.operaciones",
    },
    {
      campo: "Rol",
      valorAnterior: "Reader",
      valorNuevo: "Admin",
      fecha: "14/07/2026",
      hora: "16:48",
      usuario: "soporte.nivel2",
    },
    {
      campo: "Ocupación",
      valorAnterior: "Empleado",
      valorNuevo: "Comerciante",
      fecha: "14/07/2026",
      hora: "09:00",
      usuario: "admin.operaciones",
    },
  ],
  "ADM-002": [
    {
      campo: "Parámetros de bloqueo",
      valorAnterior: "Límite $ 500.000",
      valorNuevo: "Límite $ 100.000",
      fecha: "15/07/2026",
      hora: "10:00",
      usuario: "admin.operaciones",
    },
    {
      campo: "Parámetros de alertas",
      valorAnterior: "Volumen anormal $ 1.000.000–$ 5.000.000",
      valorNuevo: "Volumen anormal $ 500.000–$ 2.000.000",
      fecha: "13/07/2026",
      hora: "08:30",
      usuario: "soporte.nivel1",
    },
  ],
  "ADM-003": [
    {
      campo: "Nombre",
      valorAnterior: "Pedro Sánchez",
      valorNuevo: "Pedro Sánchez Gómez",
      fecha: "12/07/2026",
      hora: "15:20",
      usuario: "admin.operaciones",
    },
    {
      campo: "Estado",
      valorAnterior: "Activo",
      valorNuevo: "Suspendido",
      fecha: "10/07/2026",
      hora: "09:45",
      usuario: "soporte.nivel2",
    },
  ],
};

function parseFechaDMY(v: string): Date | null {
  const m = v.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!m) return null;
  return new Date(+m[3], +m[2] - 1, +m[1]);
}

function ActividadUsuarios() {
  const [legajo, setLegajo] = useState("");
  const [desde, setDesde] = useState("");
  const [hasta, setHasta] = useState("");
  const [consultado, setConsultado] = useState(false);

  const filtrados = consultado
    ? (ACTIVIDAD_BASE[legajo] ?? []).filter(
        (a) =>
          (!desde || (parseFechaDMY(a.fecha) ?? 0) >= (parseFechaDMY(desde) ?? 0)) &&
          (!hasta || (parseFechaDMY(a.fecha) ?? 0) <= (parseFechaDMY(hasta) ?? 0)),
      )
    : [];

  const columns: Column<Actividad>[] = [
    {
      key: "campo",
      label: "Campo actualizado",
      sortable: true,
      filterable: true,
      render: (r) => <span className="font-medium">{r.campo}</span>,
    },
    {
      key: "valorAnterior",
      label: "Valor anterior",
      render: (r) => <span className="text-muted-foreground line-through">{r.valorAnterior}</span>,
    },
    {
      key: "valorNuevo",
      label: "Valor nuevo",
      sortable: true,
      filterable: true,
      render: (r) => <span className="text-foreground font-medium">{r.valorNuevo}</span>,
    },
    {
      key: "fecha",
      label: "Fecha y hora",
      sortable: true,
      filterable: "date",
      render: (r) => (
        <span className="text-muted-foreground tabular-nums">
          {r.fecha} {r.hora}
        </span>
      ),
    },
    {
      key: "usuario",
      label: "Actualizado por",
      sortable: true,
      filterable: true,
      render: (r) => <span className="font-mono text-xs">{r.usuario}</span>,
    },
  ];

  const excelRows = filtrados.map((a) => ({
    "Campo actualizado": a.campo,
    "Valor anterior": a.valorAnterior,
    "Valor nuevo": a.valorNuevo,
    "Fecha y hora": `${a.fecha} ${a.hora}`,
    "Actualizado por": a.usuario,
  }));

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Ingresá un Legajo para consultar la actividad del usuario. Los datos se muestran como en el
        historial de cambios del detalle del usuario.
      </p>
      <div className="flex flex-wrap items-end gap-3">
        <div className="min-w-[180px]">
          <Label htmlFor="act-legajo">Legajo</Label>
          <Input
            id="act-legajo"
            value={legajo}
            onChange={(e) => {
              setLegajo(e.target.value);
              setConsultado(false);
            }}
            placeholder="Ej: ADM-001"
          />
        </div>
        <div className="min-w-[160px]">
          <Label htmlFor="act-desde">Desde</Label>
          <input
            id="act-desde"
            type="date"
            value={desde}
            onChange={(e) => {
              setDesde(e.target.value);
              setConsultado(false);
            }}
            className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40 [color-scheme:light] dark:[color-scheme:dark]"
          />
        </div>
        <div className="min-w-[160px]">
          <Label htmlFor="act-hasta">Hasta</Label>
          <input
            id="act-hasta"
            type="date"
            value={hasta}
            onChange={(e) => {
              setHasta(e.target.value);
              setConsultado(false);
            }}
            className="mt-1 w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40 [color-scheme:light] dark:[color-scheme:dark]"
          />
        </div>
        <button
          disabled={!legajo}
          onClick={() => setConsultado(true)}
          className="inline-flex items-center gap-2 h-10 px-4 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Search size={14} /> Buscar
        </button>
      </div>
      {consultado && filtrados.length > 0 && (
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <BtnOutline onClick={() => downloadExcel(`actividad_${legajo}.xlsx`, excelRows)}>
              <Download size={14} /> Descargar reporte
            </BtnOutline>
            <span className="text-sm text-muted-foreground">
              {filtrados.length} registros encontrados
            </span>
          </div>
        </div>
      )}
      {consultado && filtrados.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          No se encontraron registros para la búsqueda realizada.
        </p>
      ) : consultado ? (
        <DataTable
          columns={columns}
          data={filtrados}
          keyExtractor={(r) => r.fecha + r.hora + r.campo}
          pageSize={10}
          showDownloadButton={false}
        />
      ) : null}
    </div>
  );
}

/* ---------- Reportes de Impuestos ---------- */

type Impuesto = {
  id: string;
  reporte: string;
  periodo: string;
  tramo: string;
  creado: string;
  presentado: "Sí" | "No";
  pagado: "Sí" | "No";
  totalRegistros: number;
  totalMovimientos: number;
  totalMonto: string;
  totalRetenciones: string;
};

const IMPUESTOS_DISPONIBLES = ["Ganancias", "Ingresos Brutos", "IVA", "Débito/Crédito (Sellos)"];

const impuestosData: Impuesto[] = [
  {
    id: "IMP-0001",
    reporte: "Ganancias",
    periodo: "2026-06",
    tramo: "Tramo 1",
    creado: "2026-07-05",
    presentado: "Sí",
    pagado: "Sí",
    totalRegistros: 1240,
    totalMovimientos: 1240,
    totalMonto: "$ 8.450.000",
    totalRetenciones: "$ 1.690.000",
  },
  {
    id: "IMP-0002",
    reporte: "Ingresos Brutos",
    periodo: "2026-05",
    tramo: "Tramo 2",
    creado: "2026-06-10",
    presentado: "Sí",
    pagado: "Sí",
    totalRegistros: 980,
    totalMovimientos: 980,
    totalMonto: "$ 5.120.000",
    totalRetenciones: "$ 512.000",
  },
  {
    id: "IMP-0003",
    reporte: "IVA",
    periodo: "2026-04",
    tramo: "Tramo 1",
    creado: "2026-05-05",
    presentado: "Sí",
    pagado: "No",
    totalRegistros: 1530,
    totalMovimientos: 1530,
    totalMonto: "$ 12.300.000",
    totalRetenciones: "$ 2.460.000",
  },
  {
    id: "IMP-0004",
    reporte: "Débito/Crédito (Sellos)",
    periodo: "2026-06",
    tramo: "Tramo 3",
    creado: "2026-07-08",
    presentado: "No",
    pagado: "No",
    totalRegistros: 640,
    totalMovimientos: 640,
    totalMonto: "$ 3.210.000",
    totalRetenciones: "$ 320.000",
  },
];

function generarTxtImpuesto(r: Impuesto): string {
  return [
    `ID: ${r.id}`,
    `Reporte: ${r.reporte}`,
    `Periodo: ${r.periodo}`,
    `Tramo: ${r.tramo}`,
    `Fecha de creacion: ${r.creado}`,
    `Presentado: ${r.presentado}`,
    `Pagado: ${r.pagado}`,
    `Total registros: ${r.totalRegistros}`,
    `Total movimientos: ${r.totalMovimientos}`,
    `Total monto: ${r.totalMonto}`,
    `Total retenciones: ${r.totalRetenciones}`,
  ].join("\n");
}

function generarXmlImpuesto(r: Impuesto): string {
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    "<reporte_impuesto>",
    `  <id>${esc(r.id)}</id>`,
    `  <reporte>${esc(r.reporte)}</reporte>`,
    `  <periodo>${esc(r.periodo)}</periodo>`,
    `  <tramo>${esc(r.tramo)}</tramo>`,
    `  <fecha_creacion>${esc(r.creado)}</fecha_creacion>`,
    `  <presentado>${esc(r.presentado)}</presentado>`,
    `  <pagado>${esc(r.pagado)}</pagado>`,
    `  <total_registros>${r.totalRegistros}</total_registros>`,
    `  <total_movimientos>${r.totalMovimientos}</total_movimientos>`,
    `  <total_monto>${esc(r.totalMonto)}</total_monto>`,
    `  <total_retenciones>${esc(r.totalRetenciones)}</total_retenciones>`,
    "</reporte_impuesto>",
  ].join("\n");
}

function ImpuestoDetalleModal({
  impuesto,
  onClose,
  onMarcarPresentado,
  onMarcarPagado,
}: {
  impuesto: Impuesto;
  onClose: () => void;
  onMarcarPresentado: (id: string) => void;
  onMarcarPagado: (id: string) => void;
}) {
  const Field = ({ label, value }: { label: string; value: ReactNode }) => (
    <div>
      <div className="text-xs text-muted-foreground uppercase tracking-wide">{label}</div>
      <div className="font-medium mt-0.5">{value}</div>
    </div>
  );

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-card rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex justify-between items-start z-10">
          <div>
            <h3 className="font-display font-semibold text-lg">Detalle del reporte</h3>
            <p className="text-sm text-muted-foreground mt-0.5">{impuesto.reporte}</p>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 hover:bg-muted rounded-md">
            ×
          </button>
        </div>

        <div className="p-6 space-y-5">
          <Card className="p-5">
            <h4 className="font-display text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-4">
              Información del reporte
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
              <Field label="ID" value={<span className="font-mono">{impuesto.id}</span>} />
              <Field label="Reporte" value={impuesto.reporte} />
              <Field label="Período" value={impuesto.periodo} />
              <Field label="Tramo" value={impuesto.tramo} />
              <Field
                label="Fecha de creación"
                value={<span className="font-mono tabular-nums">{impuesto.creado}</span>}
              />
            </div>
          </Card>

          <Card className="p-5">
            <h4 className="font-display text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-4">
              KPIs
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-4">
              <Field label="Total de registros" value={impuesto.totalRegistros} />
              <Field label="Total de movimientos" value={impuesto.totalMovimientos} />
              <Field
                label="Total de monto"
                value={<span className="font-mono">{impuesto.totalMonto}</span>}
              />
              <Field
                label="Total de retenciones"
                value={<span className="font-mono">{impuesto.totalRetenciones}</span>}
              />
            </div>
          </Card>

          <Card className="p-5">
            <h4 className="font-display text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-4">
              Estado
            </h4>
            <div className="flex flex-wrap gap-6">
              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-wide">
                  Presentado
                </div>
                <div className="mt-1">
                  <Badge tone={impuesto.presentado === "Sí" ? "success" : "danger"}>
                    {impuesto.presentado}
                  </Badge>
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground uppercase tracking-wide">Pagado</div>
                <div className="mt-1">
                  <Badge tone={impuesto.pagado === "Sí" ? "success" : "danger"}>
                    {impuesto.pagado}
                  </Badge>
                </div>
              </div>
            </div>
          </Card>
        </div>

        <div className="sticky bottom-0 bg-card border-t border-border px-6 py-4 flex flex-wrap justify-end gap-2">
          {impuesto.presentado === "No" && (
            <BtnPrimary className="h-9 text-sm" onClick={() => onMarcarPresentado(impuesto.id)}>
              Marcar como presentado
            </BtnPrimary>
          )}
          {impuesto.pagado === "No" && (
            <BtnOutline className="h-9 text-sm" onClick={() => onMarcarPagado(impuesto.id)}>
              Marcar como pagado
            </BtnOutline>
          )}
          <BtnOutline className="h-9 text-sm" onClick={onClose}>
            Cerrar
          </BtnOutline>
        </div>
      </div>
    </div>
  );
}

function ReportesImpuestos() {
  const [data, setData] = useState<Impuesto[]>(impuestosData);
  const [detalle, setDetalle] = useState<Impuesto | null>(null);
  const [generando, setGenerando] = useState(false);
  const [form, setForm] = useState({ fecha: "", impuesto: "", tramo: "" });

  const marcarPresentado = (id: string) => {
    setData((prev) => prev.map((d) => (d.id === id ? { ...d, presentado: "Sí" } : d)));
    setDetalle((prev) => (prev && prev.id === id ? { ...prev, presentado: "Sí" } : prev));
    toast.success("Reporte marcado como presentado");
  };

  const marcarPagado = (id: string) => {
    setData((prev) => prev.map((d) => (d.id === id ? { ...d, pagado: "Sí" } : d)));
    setDetalle((prev) => (prev && prev.id === id ? { ...prev, pagado: "Sí" } : prev));
    toast.success("Reporte marcado como pagado");
  };

  const generarReporte = () => {
    if (!form.fecha || !form.impuesto || !form.tramo) return;
    const id = `IMP-${String(data.length + 1).padStart(4, "0")}`;
    setData((prev) => [
      ...prev,
      {
        id,
        reporte: form.impuesto,
        periodo: form.fecha.slice(0, 7),
        tramo: form.tramo,
        creado: form.fecha,
        presentado: "No",
        pagado: "No",
        totalRegistros: 0,
        totalMovimientos: 0,
        totalMonto: "$ 0",
        totalRetenciones: "$ 0",
      },
    ]);
    setForm({ fecha: "", impuesto: "", tramo: "" });
    setGenerando(false);
    toast.success("Reporte generado correctamente");
  };

  const columns: Column<Impuesto>[] = [
    {
      key: "periodo",
      label: "Período",
      filterable: true,
      sortable: true,
      render: (r) => <span className="font-mono tabular-nums">{r.periodo}</span>,
    },
    {
      key: "tramo",
      label: "Tramo",
      filterable: "enum",
      filterOptions: ["Tramo 1", "Tramo 2", "Tramo 3"],
      render: (r) => r.tramo,
    },
    {
      key: "creado",
      label: "Fecha de creación",
      filterable: "date",
      render: (r) => <span className="font-mono tabular-nums">{r.creado}</span>,
    },
    {
      key: "presentado",
      label: "Presentado",
      filterable: "enum",
      filterOptions: ["Sí", "No"],
      render: (r) => (
        <Badge tone={r.presentado === "Sí" ? "success" : "danger"}>{r.presentado}</Badge>
      ),
    },
    {
      key: "pagado",
      label: "Pagado",
      filterable: "enum",
      filterOptions: ["Sí", "No"],
      render: (r) => <Badge tone={r.pagado === "Sí" ? "success" : "danger"}>{r.pagado}</Badge>,
    },
  ];

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
        <p className="text-sm text-muted-foreground">
          Reportes de presentación de impuestos por período y tramo.
        </p>
        <BtnPrimary type="button" className="h-9 text-sm" onClick={() => setGenerando(true)}>
          <Plus size={14} /> Generar reporte
        </BtnPrimary>
      </div>

      <DataTable
        columns={columns}
        data={data}
        keyExtractor={(r) => r.id}
        pageSize={10}
        showDownloadButton={false}
        actions={(r) => (
          <div className="flex items-center gap-1">
            <BtnOutline
              className="h-7 px-2 text-xs"
              onClick={() => setDetalle(r)}
              title="Ver detalle"
            >
              <FileText size={14} /> Ver detalle
            </BtnOutline>
            <BtnOutline
              className="h-7 px-2 text-xs"
              onClick={() => downloadFile(`${r.reporte}_${r.periodo}.txt`, generarTxtImpuesto(r))}
              title="Descargar TXT"
            >
              <Download size={14} /> TXT
            </BtnOutline>
            <BtnOutline
              className="h-7 px-2 text-xs"
              onClick={() => downloadFile(`${r.reporte}_${r.periodo}.xml`, generarXmlImpuesto(r))}
              title="Descargar XML"
            >
              <Download size={14} /> XML
            </BtnOutline>
            <BtnOutline
              className="h-7 px-2 text-xs"
              onClick={() => downloadFile(`${r.reporte}_${r.periodo}.zip`, "")}
              title="Descargar ZIP"
            >
              <Download size={14} /> ZIP
            </BtnOutline>
          </div>
        )}
      />

      {detalle && (
        <ImpuestoDetalleModal
          impuesto={detalle}
          onClose={() => setDetalle(null)}
          onMarcarPresentado={marcarPresentado}
          onMarcarPagado={marcarPagado}
        />
      )}

      {generando && (
        <FormDialog
          open
          onClose={() => setGenerando(false)}
          title="Generar reporte"
          description="Completá los datos para generar un nuevo reporte de impuesto."
          onSubmit={generarReporte}
          submitLabel="Generar reporte"
          size="md"
        >
          <div>
            <Label htmlFor="ri-fecha">Fecha</Label>
            <input
              id="ri-fecha"
              type="date"
              value={form.fecha}
              onChange={(e) => setForm((f) => ({ ...f, fecha: e.target.value }))}
              className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40 [color-scheme:light] dark:[color-scheme:dark]"
            />
          </div>
          <div>
            <Label htmlFor="ri-impuesto">Impuesto para el reporte</Label>
            <select
              id="ri-impuesto"
              className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40"
              value={form.impuesto}
              onChange={(e) => setForm((f) => ({ ...f, impuesto: e.target.value }))}
            >
              <option value="">Seleccionar impuesto</option>
              {IMPUESTOS_DISPONIBLES.map((i) => (
                <option key={i} value={i}>
                  {i}
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label htmlFor="ri-tramo">Tramo</Label>
            <select
              id="ri-tramo"
              className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40"
              value={form.tramo}
              onChange={(e) => setForm((f) => ({ ...f, tramo: e.target.value }))}
            >
              <option value="">Seleccionar tramo</option>
              <option value="Tramo 1">Tramo 1</option>
              <option value="Tramo 2">Tramo 2</option>
              <option value="Tramo 3">Tramo 3</option>
            </select>
          </div>
        </FormDialog>
      )}
    </div>
  );
}

/* ---------- Conciliaciones BLP ---------- */

type BlpArchivo = {
  archivo: string;
  fecha: string;
  estado: "Presentada" | "Liquidada" | "Pendiente" | "En proceso";
};

const blpData: BlpArchivo[] = [
  { archivo: "Liquidada Payway 2026-07.csv", fecha: "2026-07-31", estado: "Liquidada" },
  { archivo: "Pagos Payway 2026-07.csv", fecha: "2026-07-30", estado: "Presentada" },
  { archivo: "Pagos Payway 2026-06.csv", fecha: "2026-06-30", estado: "Presentada" },
  { archivo: "Liquidada Payway 2026-06.csv", fecha: "2026-06-29", estado: "Liquidada" },
  { archivo: "Pagos Payway 2026-05.csv", fecha: "2026-05-30", estado: "En proceso" },
];

function BlpNoRequiereModal({ archivo, onClose }: { archivo: string; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-card rounded-xl w-full max-w-md shadow-xl">
        <div className="p-6">
          <h3 className="font-display font-semibold text-lg">Análisis de conciliación</h3>
          <p className="text-sm text-muted-foreground mt-3">
            El archivo <span className="font-mono">{archivo}</span> no requiere análisis.
          </p>
          <div className="mt-5 flex justify-end">
            <BtnOutline className="h-9 text-sm px-3" onClick={onClose}>
              Cerrar
            </BtnOutline>
          </div>
        </div>
      </div>
    </div>
  );
}

function BlpAnalisisModal({ archivo, onClose }: { archivo: BlpArchivo; onClose: () => void }) {
  const [ejecutado, setEjecutado] = useState(false);
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-card rounded-xl w-full max-w-md shadow-xl">
        <div className="p-6 space-y-4">
          <h3 className="font-display font-semibold text-lg">Analizar conciliación</h3>
          <div className="text-sm text-muted-foreground space-y-1">
            <div>
              <span className="text-foreground font-medium">Archivo:</span>{" "}
              <span className="font-mono">{archivo.archivo}</span>
            </div>
            <div>
              <span className="text-foreground font-medium">Fecha:</span>{" "}
              <span className="font-mono">{archivo.fecha}</span>
            </div>
            <div>
              <span className="text-foreground font-medium">Estado:</span> {archivo.estado}
            </div>
          </div>
          <p className="text-sm">
            Se ejecutará el análisis de la conciliación BLP correspondiente.
          </p>
          {ejecutado && (
            <div className="rounded-md border border-emerald-500/30 bg-emerald-500/10 text-emerald-600 text-sm px-3 py-2">
              Análisis ejecutado correctamente.
            </div>
          )}
          <div className="flex justify-end gap-2">
            <BtnOutline className="h-9 text-sm px-3" onClick={onClose}>
              Cerrar
            </BtnOutline>
            <BtnPrimary
              className="h-9 text-sm px-3"
              onClick={() => {
                setEjecutado(true);
                toast.success("Análisis de conciliación ejecutado");
              }}
            >
              Ejecutar análisis
            </BtnPrimary>
          </div>
        </div>
      </div>
    </div>
  );
}

function ConciliacionesBLP() {
  const [data, setData] = useState<BlpArchivo[]>(blpData);
  const [cargando, setCargando] = useState(false);
  const [saving, setSaving] = useState(false);
  const [analisisTarget, setAnalisisTarget] = useState<BlpArchivo | null>(null);
  const [noRequiere, setNoRequiere] = useState<string | null>(null);
  const [cargarForm, setCargarForm] = useState({
    nombre: "",
    fecha: "",
    file: null as File | null,
  });

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    listConciliacionesArchivos({ page: 0, pageSize: 50, tipo: "blp" })
      .then((res) => {
        if (res.rows.length > 0) {
          setData(
            res.rows.map((r) => ({
              archivo: r.nombreArchivo,
              fecha: r.fechaCarga,
              estado: r.estado as BlpArchivo["estado"],
            })),
          );
        }
      })
      .catch(() => {});
  }, []);

  const guardarArchivo = async () => {
    if (!cargarForm.nombre.trim() || !cargarForm.fecha || !cargarForm.file) {
      toast.error("Completá nombre, fecha y archivo");
      return;
    }
    const nombreArchivo = cargarForm.file.name || cargarForm.nombre.trim();
    if (isSupabaseConfigured) {
      setSaving(true);
      try {
        const created = await createConciliacionArchivo({
          nombreArchivo,
          fechaCarga: cargarForm.fecha,
          tipo: "blp",
          estado: "Pendiente",
          file: cargarForm.file,
        });
        setData((prev) => [
          { archivo: created.nombreArchivo, fecha: created.fechaCarga, estado: "Pendiente" },
          ...prev,
        ]);
        toast.success("Archivo BLP guardado en base de datos");
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : String(e);
        if (/Could not find the table|PGRST205|does not exist/i.test(msg)) {
          setData((prev) => [
            { archivo: nombreArchivo, fecha: cargarForm.fecha, estado: "Pendiente" },
            ...prev,
          ]);
          toast.success("Archivo cargado (modo local: aplicá migración 0016)");
        } else {
          toast.error(`Error al guardar: ${msg}`);
          setSaving(false);
          return;
        }
      } finally {
        setSaving(false);
      }
    } else {
      setData((prev) => [
        { archivo: nombreArchivo, fecha: cargarForm.fecha, estado: "Pendiente" },
        ...prev,
      ]);
      toast.success("Archivo cargado correctamente");
    }
    setCargarForm({ nombre: "", fecha: "", file: null });
    setCargando(false);
  };

  const abrirAnalisis = (r: BlpArchivo) => {
    if (r.estado === "Presentada" || r.estado === "Liquidada") {
      setAnalisisTarget(r);
    } else {
      setNoRequiere(r.archivo);
    }
  };

  const columns: Column<BlpArchivo>[] = [
    {
      key: "archivo",
      label: "Nombre del archivo",
      filterable: true,
      render: (r) => <span className="font-mono text-xs">{r.archivo}</span>,
    },
    {
      key: "fecha",
      label: "Fecha",
      filterable: "date",
      render: (r) => <span className="font-mono tabular-nums">{r.fecha}</span>,
    },
    {
      key: "accion",
      label: "Acción",
      render: (r) => (
        <div className="flex items-center gap-1">
          <BtnOutline
            className="h-7 text-xs px-3"
            onClick={() =>
              downloadFile(
                r.archivo,
                `Archivo de conciliación BLP: ${r.archivo}\nFecha: ${r.fecha}\nEstado: ${r.estado}`,
              )
            }
          >
            <Download size={14} /> Descargar
          </BtnOutline>
          <BtnOutline className="h-7 text-xs px-3" onClick={() => abrirAnalisis(r)}>
            Analizar
          </BtnOutline>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
        <p className="text-sm text-muted-foreground">
          Conciliación de archivos Payway (pagos y liquidaciones) por Link de Pago.
        </p>
        <BtnPrimary type="button" className="h-9 text-sm" onClick={() => setCargando(true)}>
          <Plus size={14} /> Cargar nuevo archivo
        </BtnPrimary>
      </div>

      <DataTable
        columns={columns}
        data={data}
        keyExtractor={(r) => r.archivo}
        pageSize={10}
        showDownloadButton={false}
      />

      {cargando && (
        <FormDialog
          open
          onClose={() => (saving ? null : setCargando(false))}
          title="Cargar nuevo archivo"
          description="Se guarda en la base de datos (tipo BLP)."
          onSubmit={guardarArchivo}
          submitLabel={saving ? "Guardando..." : "Guardar"}
          size="md"
        >
          <div>
            <Label htmlFor="blp-nombre">Nombre del archivo</Label>
            <Input
              id="blp-nombre"
              value={cargarForm.nombre}
              onChange={(e) => setCargarForm((f) => ({ ...f, nombre: e.target.value }))}
              placeholder="Liquidada Payway 2026-08.csv"
            />
          </div>
          <div>
            <Label htmlFor="blp-fecha">Fecha</Label>
            <input
              id="blp-fecha"
              type="date"
              value={cargarForm.fecha}
              onChange={(e) => setCargarForm((f) => ({ ...f, fecha: e.target.value }))}
              className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring/40 [color-scheme:light] dark:[color-scheme:dark]"
            />
          </div>
          <div>
            <Label>Archivo de conciliación BLP</Label>
            <FileDropzone
              accept=".csv,.xlsx,.xls"
              onFile={(f) =>
                setCargarForm((fr) => ({ ...fr, file: f, nombre: f?.name ?? fr.nombre }))
              }
            />
          </div>
        </FormDialog>
      )}

      {noRequiere && (
        <BlpNoRequiereModal archivo={noRequiere} onClose={() => setNoRequiere(null)} />
      )}
      {analisisTarget && (
        <BlpAnalisisModal archivo={analisisTarget} onClose={() => setAnalisisTarget(null)} />
      )}
    </div>
  );
}

function ReporteUnidadNegocio() {
  const data = [
    { unidad: "CBU", generaMoliPay: "$ 450.000", payWay: "$ 320.000", neto: "$ 130.000", impuestos: "$ 45.000", total: "$ 945.000" },
    { unidad: "CBU / CBU chica U", generaMoliPay: "$ 180.000", payWay: "$ 120.000", neto: "$ 60.000", impuestos: "$ 18.000", total: "$ 378.000" },
    { unidad: "Pago por QR", generaMoliPay: "$ 95.000", payWay: "$ 70.000", neto: "$ 25.000", impuestos: "$ 12.000", total: "$ 202.000" },
    { unidad: "Link de Pago", generaMoliPay: "$ 620.000", payWay: "$ 810.000", neto: "$ -190.000", impuestos: "$ 310.000", total: "$ 1.740.000" },
    { unidad: "E-commerce", generaMoliPay: "$ 510.000", payWay: "$ 680.000", neto: "$ -170.000", impuestos: "$ 260.000", total: "$ 1.450.000" },
  ];
  const columns: Column<(typeof data)[number]>[] = [
    { key: "unidad", label: "Unidad de negocio", filterable: true, render: (r) => <span className="font-semibold">{r.unidad}</span> },
    { key: "generaMoliPay", label: "Genera MoliPay", render: (r) => <span className="font-mono text-emerald-700">{r.generaMoliPay}</span> },
    { key: "payWay", label: "Corresponde PayWay", render: (r) => <span className="font-mono">{r.payWay}</span> },
    { key: "neto", label: "Neto", render: (r) => <span className="font-mono font-semibold">{r.neto}</span> },
    { key: "impuestos", label: "Impuestos", render: (r) => <span className="font-mono">{r.impuestos}</span> },
    { key: "total", label: "Total", render: (r) => <span className="font-mono font-semibold">{r.total}</span> },
    { key: "xls", label: "XLS", render: (r) => <button onClick={() => downloadExcel(`unidad_${r.unidad}.xlsx`, [r])} className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"><Download size={14}/> XLS</button> },
  ];
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">Análisis por unidad de negocio — cuánto deja cada unidad (MoliPay vs PayWay vs neto).</p>
      <DataTable columns={columns} data={data} keyExtractor={(r) => r.unidad} pageSize={10} showDownloadButton={false} />
    </div>
  );
}

/* ---------- Enrutado de vistas ---------- */

const views: Record<string, () => ReactNode> = {
  conciliaciones: Conciliaciones,
  bcra: ReportesBCRA,
  afip: ReportesAFIP,
  comisiones: ReportesComisiones,
  movimientos: ReportesMovimientos,
  actividad: ActividadUsuarios,
  impuestos: ReportesImpuestos,
  "conciliaciones-blp": ConciliacionesBLP,
  "unidad-negocio": ReporteUnidadNegocio,
};

function Page() {
  const [selected, setSelected] = useState<string | null>(null);
  const current = reports.find((r) => r.key === selected);
  const View = current ? views[current.key] : undefined;

  if (current && View) {
    return (
      <>
        <button
          onClick={() => setSelected(null)}
          className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:text-primary/80 mb-4"
        >
          <ChevronLeft size={16} /> Volver a Reportes
        </button>
        <PageHeader title={current.name} description={current.description} />
        <View />
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Reportes"
        description="Conciliaciones, reportes regulatorios y de impuestos"
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {reports.map((r) => {
          const Icon = r.icon;
          return (
            <button
              key={r.key}
              onClick={() => setSelected(r.key)}
              className="bg-card border border-border rounded-xl p-5 text-left hover:border-primary/50 hover:shadow-lg shadow-sm transition-all"
            >
              <Icon size={28} className={`${r.color} mb-3`} strokeWidth={1.75} />
              <div className="font-semibold text-foreground text-sm">{r.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{r.description}</div>
            </button>
          );
        })}
      </div>
    </>
  );
}
